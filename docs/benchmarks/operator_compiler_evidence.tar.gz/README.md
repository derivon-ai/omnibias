# Operator compiler evidence

This archive contains the original JSON reports (including every raw timing
sample and failure), a regenerated summary, exact content-addressed source
snapshots, and license notices. It contains no compiler caches.
Optional attachments are copied verbatim for diagnostics, hardware information
or verification logs. They are not interpreted as measurements or timing evidence.
Optional dependency licenses are included only when their source snapshots are
bundled, and recorded dependency versions must match installed license metadata.

The summary treats each input report independently. A timing aggregate requires
three successful, unchanged-source, accuracy-gated processes with at least twenty
samples, matching query configuration and backend versions. Failed, refused or
timed-out cells receive no ratios; their completed stages remain in raw reports.
Numbers are medians of per-process medians. Compilation/first-call and memory
fields retain the original report scopes; RSS is not a tensor allocation peak.

To reproduce a report, first inspect its config, environment and source_revision.
Check out that base repository revision and RESTORE THE SNAPSHOTS: the measured
working tree was dirty, so checkout alone does not reproduce the implementation.
manifest.json maps each original path and revision to sources/<sha256>. Select
the source hashes from the particular report/cell, copy repository files to
those relative paths, and verify SHA-256. Baseline paths are installed-package
paths; restore them only into a suitable isolated environment. Do not blindly
write absolute paths from metadata. Different reports may use different revisions.

Install matching recorded Python/framework/optional-baseline versions, preserve
the CPU/thread/cache policy, and rerun benchmarks/operator_compiler.py with that
report's config. Failed resource-limited cells are bounded experiments, not proof
that the baseline can never run. Accuracy probes are not exhaustive error bounds.

To rebuild a package from available original reports/snapshots:
python benchmarks/operator_report.py --inputs REPORT.json [REPORT2.json ...] \
  --accuracy ACCURACY.json --output summary.json --archive evidence.tar.gz
The optional accuracy argument may be omitted. The packager verifies source
content before writing either output. It never merges measurements across inputs.
Use --attachments FILE [FILE ...] to include additional files without interpreting
their contents. Every attachment's original path and SHA-256 are in the manifest.
