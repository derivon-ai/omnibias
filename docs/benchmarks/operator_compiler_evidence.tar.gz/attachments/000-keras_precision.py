"""Reproduce installed Keras/JAX float64 promotion loss without changing Keras.

Run from the repository:
KERAS_BACKEND=jax JAX_ENABLE_X64=1 JAX_PLATFORMS=cpu CUDA_VISIBLE_DEVICES='' \
    .venv/bin/python artifacts/operator-evidence/keras_precision.py

This is diagnostic evidence, not a runtime implementation or benchmark.
"""

import json
import platform

import jax
import jax.numpy as jnp
import keras
import mpmath as mp
import numpy as np
from keras import ops
from omnibias.keras.experimental import OperatorSpec, operator_model

mp.mp.dps = 100
x = jnp.array([[0.1234567890123]], dtype=jnp.float64)
result = {
    "python_version": platform.python_version(),
    "keras_version": keras.__version__,
    "jax_version": jax.__version__,
    "backend": keras.backend.backend(),
    "jax_enable_x64": bool(jax.config.jax_enable_x64),
    "source": "unmodified installed Keras; no dtype monkeypatch",
    "dtype_probes": [],
}
for default_dtype in ("float32", "float64"):
    keras.config.set_floatx(default_dtype)
    actual = ops.tanh(x)
    expected = jnp.tanh(x)
    result["dtype_probes"].append({
        "floatx": default_dtype,
        "strong_promotion": keras.backend.result_type("float64", "float64"),
        "weak_promotion": keras.backend.result_type("float64", float),
        "input_dtype": str(x.dtype),
        "keras_tanh_dtype": str(actual.dtype),
        "keras_tanh_value": float(actual.item()),
        "jax_tanh_dtype": str(expected.dtype),
        "jax_tanh_value": float(expected.item()),
    })

inputs = keras.Input((1,), dtype="float64")
source = keras.Model(inputs, keras.layers.Dense(1, activation="tanh", dtype="float64")(inputs))
source.set_weights([np.array([[0.7]]), np.array([0.1])])
derivative = operator_model(source, operator=OperatorSpec.mixed((2,)))
actual = float(ops.convert_to_numpy(derivative(x)).item())
z = mp.mpf(0.7) * mp.mpf(float(x.item())) + mp.mpf(0.1)
expected = float(mp.mpf(0.7)**2 * mp.diff(mp.tanh, z, 2))
result["operator_probe"] = {
    "source_output_dtype": str(source(x).dtype),
    "operator_output_dtype": str(derivative(x).dtype),
    "operator_value": actual,
    "ideal_float64_mpmath_reference": expected,
    "absolute_error": abs(actual - expected),
    "relative_error": abs((actual - expected) / expected),
    "accepted_for_strict_float64_timing": False,
}
print(json.dumps(result, indent=2))
