"""Record sequential, single-CPU Keras package validation without changing dependencies."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE_FILES = sorted((ROOT / 'packages/omnibias-keras/src').rglob('*.py'))
SOURCE_FILES += sorted((ROOT / 'packages/omnibias-keras/tests').glob('test_*precision*.py'))
SOURCE_FILES += [ROOT / 'packages/omnibias-core/src/omnibias/core' / name for name in
                 ('jet_algebra.py', 'jet_series.py', 'jet_systems.py', 'operator_spec.py',
                  'operator_polynomial.py', 'operator_quotient.py', 'apolar.py')]


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    for backend in ('torch', 'jax', 'tensorflow'):
        overrides = {'KERAS_BACKEND': backend, 'CUDA_VISIBLE_DEVICES': '',
                     'MPLCONFIGDIR': '/tmp/mpl', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
                     'TORCHINDUCTOR_COMPILE_THREADS': '1'}
        if backend == 'torch':
            overrides['TORCHINDUCTOR_CACHE_DIR'] = '/tmp/omnibias-keras-precision'
        if backend == 'jax':
            overrides.update(JAX_ENABLE_X64='1', JAX_PLATFORMS='cpu')
        if backend == 'tensorflow':
            overrides.update(PYTHONPATH='/tmp/omnibias-tf-validation', TF_CPP_MIN_LOG_LEVEL='2')
        env = dict(os.environ)
        env.update(overrides)
        argv = [str(ROOT / '.venv/bin/python'), '-m', 'pytest',
                'packages/omnibias-keras/tests', '-q', '--maxfail=2']
        if shutil.which('taskset'):
            argv = ['taskset', '-c', '1', *argv]
        record = {'argv': argv, 'cwd': str(ROOT), 'environment': overrides,
                  'started_utc': now(), 'scope': 'Full Keras package default suite; no added exclusions; numerical/runtime source unchanged.',
                  'source_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in SOURCE_FILES}}
        manifest = OUT / f'keras-full-{backend}.command.json'
        log = OUT / f'keras-full-{backend}.log'
        manifest.write_text(json.dumps(record, indent=2)+'\n')
        start = time.perf_counter()
        print(f'{backend}: started, log={log.name}', flush=True)
        with log.open('w') as output:
            result = subprocess.run(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
        record.update(returncode=result.returncode, finished_utc=now(), elapsed_seconds=time.perf_counter()-start,
                      log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        manifest.write_text(json.dumps(record, indent=2)+'\n')
        print(f'{backend}: returncode={result.returncode}; {log.read_text().splitlines()[-1]}', flush=True)
        if result.returncode:
            return result.returncode
    return 0


if __name__ == '__main__':
    sys.exit(main())
