#!/usr/bin/env python3
"""Frozen-source sequential matrix; execute only after the coordinator's GO."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


REPO = Path(__file__).resolve().parents[2]
OUTPUT = Path(__file__).resolve().parent
PYTHON = REPO / ".venv/bin/python"
JOBS = (
    ("ridge", ["--families", "ridge", "--orders", "2", "4", "6", "8",
               "--methods", "compiler", "manual", "jax-manual", "jax-nested", "folx", "keras-jax"]),
    ("separable", ["--families", "separable", "--orders", "4", "8", "24", "32",
                   "--methods", "compiler", "manual", "reference", "nested"]),
    ("bottleneck", ["--families", "bottleneck", "--dim", "32", "--latent", "2", "--orders", "2", "4",
                    "--methods", "compiler", "manual", "folx", "torch-jet", "keras-jax"]),
    ("coupled", ["--families", "coupled", "--orders", "4", "16", "32",
                 "--methods", "compiler", "manual", "reference", "jax-jet", "torch-jet", "nested"]),
)
COMMON = ["--cache", "persistent", "--replicates", "3", "--repeats", "20", "--warmup", "3",
          "--threads", "1", "--timeout", "120", "--rss-limit-mib", "3072",
          "--activation-method", "recurrence", "--kernel-lowering", "auto", "--precision", "strict"]


def utc() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()


def source_hashes() -> dict[str, str]:
    paths = set((REPO / "benchmarks").glob("*.py"))
    for package in ("omnibias-core", "omnibias-torch", "omnibias-keras"):
        paths.update((REPO / "packages" / package / "src").rglob("*.py"))
    return {str(path.relative_to(REPO)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths)}


def save(manifest: dict) -> None:
    (OUTPUT / "matrix-command-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", action="store_true", help="coordinator authorized execution")
    args = parser.parse_args()
    if not args.go:
        print("Prepared 204-cell matrix. Waiting for coordinator GO; no benchmarks started.")
        return
    if any((OUTPUT / f"{name}.json").exists() for name, _ in JOBS):
        raise SystemExit("Existing matrix evidence found; refusing to overwrite it.")
    os.chdir(REPO)
    os.sched_setaffinity(0, {2})
    environment = dict(os.environ)
    environment.update(OMNIBIAS_SCRATCH=str(OUTPUT), CUDA_VISIBLE_DEVICES="", TORCHINDUCTOR_COMPILE_THREADS="1",
                       OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", JAX_PLATFORMS="cpu",
                       PYTHONPATH="/tmp/omnibias-jet-comparison")
    # A fresh matrix owns its persistent cache; do not inherit unrelated cache paths.
    removed = {key: environment.pop(key) for key in (
        "TORCHINDUCTOR_CACHE_DIR", "JAX_COMPILATION_CACHE_DIR", "TORCHINDUCTOR_FORCE_DISABLE_CACHES",
        "TORCH_COMPILE_FORCE_DISABLE_CACHES", "JAX_ENABLE_COMPILATION_CACHE"
    ) if key in environment}
    before = source_hashes()
    manifest = {
        "schema": "omnibias/operator-matrix-command/v1", "started_utc": utc(), "cwd": str(REPO),
        "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)), "sequential": True, "planned_cells": 204,
        "environment": {key: environment[key] for key in (
            "OMNIBIAS_SCRATCH", "CUDA_VISIBLE_DEVICES", "TORCHINDUCTOR_COMPILE_THREADS",
            "OMP_NUM_THREADS", "MKL_NUM_THREADS", "JAX_PLATFORMS", "PYTHONPATH")},
        "removed_inherited_cache_environment": removed,
        "optional_baseline_path_present": Path("/tmp/omnibias-jet-comparison/jet").is_dir(),
        "cache_scope": "Fresh matrix directory initially; persistent cache shared by sequential workers within this matrix.",
        "source_sha256": before, "jobs": [], "status": "running",
    }
    save(manifest)
    for name, arguments in JOBS:
        if source_hashes() != before:
            manifest.update(status="source_changed", finished_utc=utc())
            save(manifest)
            raise SystemExit("Frozen source changed; preserved all existing results and stopped.")
        command = [str(PYTHON), "benchmarks/operator_compiler.py", *arguments, *COMMON, "--output", f"{name}.json"]
        record = {"name": name, "argv": command, "started_utc": utc(), "status": "running"}
        manifest["jobs"].append(record)
        save(manifest)
        start = time.monotonic()
        print(f"START {name} {record['started_utc']}", flush=True)
        with (OUTPUT / f"{name}.log").open("w") as log:
            process = subprocess.Popen(command, env=environment, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True)
            assert process.stdout is not None
            for line in process.stdout:
                log.write(line)
                log.flush()
                print(line, end="", flush=True)
            returncode = process.wait()
        record.update(returncode=returncode, finished_utc=utc(), elapsed_seconds=time.monotonic() - start,
                      status="completed" if returncode == 0 else "command_failed")
        report = OUTPUT / f"{name}.json"
        if report.exists():
            payload = json.loads(report.read_text())
            counts: dict[str, int] = {}
            for row in payload.get("rows", []):
                status = row.get("status", "missing")
                counts[status] = counts.get(status, 0) + 1
            record.update(report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(), status_counts=counts,
                          actual_cells=len(payload.get("rows", [])))
        save(manifest)
        if name == "ridge":
            gates = [{"order": item["order"], "method": item["compiled_method"],
                      "passed": item.get("ridge_release_gate_pass"),
                      "medians_ms": item["median_of_process_medians_ms"]}
                     for item in payload.get("comparisons", [])]
            record["ridge_gates"] = gates
            torch_gates = {item["order"]: item["passed"] for item in gates if item["method"] == "compiler"}
            print("RIDGE GATES " + json.dumps(gates), flush=True)
            if torch_gates != {2: True, 4: True, 6: True, 8: True} or any(item["passed"] is False for item in gates):
                manifest.update(status="held_for_ridge_gate_diagnosis", finished_utc=utc())
                save(manifest)
                raise SystemExit("Ridge gate failed or incomplete; held before other families for coordinator diagnosis.")
            save(manifest)
    manifest.update(finished_utc=utc(), source_unchanged=source_hashes() == before,
                    status="completed" if all(job["returncode"] == 0 for job in manifest["jobs"]) else "command_failures")
    save(manifest)
    print("MATRIX COMPLETE", flush=True)


if __name__ == "__main__":
    main()
